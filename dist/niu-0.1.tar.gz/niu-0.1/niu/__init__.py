from Goal import Goal
from Solver import solve
from Filter import Filter
from Goal import GoalTypes

# Potential names:
# niu - coconut
# poepoe - round
# pola - bowl